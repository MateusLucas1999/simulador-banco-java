
public class Conta {
    private String titular;
    private int numero;
    private double saldo;
    
    public Conta(String titular,int numero){
        this.titular = titular;
        this.numero = numero ;
        this.saldo = 0.0;
    }
    public void depositar(double valor){
        saldo+= valor;
    }
    
    public boolean sacar(double valor){
        if(valor <= saldo){
            saldo-= valor;
            return true;
        }
        return false;
    }
    public String getTitular(){
        return titular;
    }
    public int getNumero(){
        return numero;
    }
    public double getSaldo(){
        return saldo;
    }
    
}

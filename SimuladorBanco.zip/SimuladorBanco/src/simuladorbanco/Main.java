import java.util.Scanner;

public class Main {

    
    public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
      Banco banco = new Banco();
      
         while (true) {
            System.out.println("\n1. Criar Conta\n2. Depositar\n3. Sacar\n4. Ver Saldo\n0. Sair");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();
        
            if (opcao == 0) break;
            
            switch (opcao) {
                case 1:
                    System.out.print("Titular: ");
                    scanner.nextLine();
                    String nome = scanner.nextLine();
                    System.out.print("Número da conta: ");
                    int numero = scanner.nextInt();
                    banco.adicionarConta(new Conta(nome, numero));
                    break;
                case 2:
                    System.out.print("Número da conta: ");
                    int numDep = scanner.nextInt();
                    Conta contaDep = banco.buscarConta(numDep);
                    if (contaDep != null) {
                        System.out.print("Valor: ");
                        double valor = scanner.nextDouble();
                        contaDep.depositar(valor);
                         } else {
                        System.out.println("Conta não encontrada.");
                        }
                         break;
                    case 3:
                    System.out.print("Número da conta: ");
                    int numSaq = scanner.nextInt();
                    Conta contaSaq = banco.buscarConta(numSaq);
                    if (contaSaq != null) {
                        System.out.print("Valor: ");
                        double valor = scanner.nextDouble();
                        if (!contaSaq.sacar(valor)) {
                            System.out.println("Saldo insuficiente.");
                        }
                    } else {
                        System.out.println("Conta não encontrada.");
                    }
                    break;
                    case 4:
                    System.out.print("Número da conta: ");
                    int numSaldo = scanner.nextInt();
                    Conta contaSaldo = banco.buscarConta(numSaldo);
                    if (contaSaldo != null) {
                        System.out.println("Saldo: R$ " + contaSaldo.getSaldo());
                    } else {
                        System.out.println("Conta não encontrada.");
                    }
                    break;
           default:
                    System.out.println("Opção inválida.");
            }
        }

        scanner.close();
    }
    
}
